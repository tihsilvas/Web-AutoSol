-- phpMyAdmin SQL Dump
-- version 5.2.1
-- https://www.phpmyadmin.net/
--
-- Host: 127.0.0.1
-- Tempo de geração: 04/12/2023 às 23:21
-- Versão do servidor: 10.4.28-MariaDB
-- Versão do PHP: 8.0.28

SET SQL_MODE = "NO_AUTO_VALUE_ON_ZERO";
START TRANSACTION;
SET time_zone = "+00:00";


/*!40101 SET @OLD_CHARACTER_SET_CLIENT=@@CHARACTER_SET_CLIENT */;
/*!40101 SET @OLD_CHARACTER_SET_RESULTS=@@CHARACTER_SET_RESULTS */;
/*!40101 SET @OLD_COLLATION_CONNECTION=@@COLLATION_CONNECTION */;
/*!40101 SET NAMES utf8mb4 */;

--
-- Banco de dados: `inter`
--

-- --------------------------------------------------------

--
-- Estrutura para tabela `registro`
--

CREATE TABLE `registro` (
  `id_registro` int(11) NOT NULL,
  `email_cliente` varchar(30) NOT NULL,
  `senha_cliente` varchar(30) NOT NULL,
  `nome_cliente` varchar(50) NOT NULL,
  `cpf_cliente` varchar(11) NOT NULL,
  `dt_nasc_cliente` date NOT NULL,
  `rg_cliente` varchar(12) NOT NULL,
  `telefone_cliente` int(11) NOT NULL,
  `cep_cliente` int(8) NOT NULL,
  `estado_cliente` varchar(20) NOT NULL,
  `cidade_cliente` varchar(25) NOT NULL,
  `rua_cliente` varchar(20) NOT NULL,
  `bairro_cliente` varchar(20) NOT NULL,
  `comp_cliente` varchar(30) NOT NULL
) ENGINE=InnoDB DEFAULT CHARSET=utf8mb4 COLLATE=utf8mb4_general_ci;

--
-- Despejando dados para a tabela `registro`
--

INSERT INTO `registro` (`id_registro`, `email_cliente`, `senha_cliente`, `nome_cliente`, `cpf_cliente`, `dt_nasc_cliente`, `rg_cliente`, `telefone_cliente`, `cep_cliente`, `estado_cliente`, `cidade_cliente`, `rua_cliente`, `bairro_cliente`, `comp_cliente`) VALUES
(20, 'Lorenzo@gmail.com', '123456', 'Lorenzo Rossi', '11111111111', '1111-11-11', '11111111', 2147483647, 11111111, 'SP', 'SP', 'SP', 'SP', 'SP'),
(21, 'teste@gmail.com', '123456', 'YourToba', '11111111111', '2023-12-04', '11111111', 2147483647, 11111111, 'SP', 'SP', 'SP', 'SP', 'SP');

--
-- Índices para tabelas despejadas
--

--
-- Índices de tabela `registro`
--
ALTER TABLE `registro`
  ADD PRIMARY KEY (`id_registro`);

--
-- AUTO_INCREMENT para tabelas despejadas
--

--
-- AUTO_INCREMENT de tabela `registro`
--
ALTER TABLE `registro`
  MODIFY `id_registro` int(11) NOT NULL AUTO_INCREMENT, AUTO_INCREMENT=22;
COMMIT;

/*!40101 SET CHARACTER_SET_CLIENT=@OLD_CHARACTER_SET_CLIENT */;
/*!40101 SET CHARACTER_SET_RESULTS=@OLD_CHARACTER_SET_RESULTS */;
/*!40101 SET COLLATION_CONNECTION=@OLD_COLLATION_CONNECTION */;

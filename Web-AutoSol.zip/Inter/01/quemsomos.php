<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" href="CSS/quemsomos.css">
    <title>Document</title>
</head>
<body>
    <?php
        require_once("includes/header.php");
    ?>

    <main>
        <p class="titulo_somos">"Quem é a Autosol?"</p>
        
        <div class="linha_somos"></div>
        <p class="subtitulo_somos">"Nossa História"</p>
        <center><div class="linhasub_somos"></div></center>

        <div class="conteudo_somos">
            <div class="poster_somos">
                <img src="IMG/empresa.jpg" class="poster_img">
            </div>
            <div class="texto_somos">
                <p class="info_somos">A AutoSol é uma empresa inovadora, sendo fundada em São Paulo, durante
                    os anos 90, com a ideia de utilizar a energia Solar para poder utiliza-la em
                    veículos de pequeno e grande porte, com o passar dos anos, o catalogo de
                    itens foi sendo expandido, com bicicletas e patinetes, revolucionando o transporte em nosso país.</p>
            </div>
        </div>

        <div class="linha_somos"></div>
        <p class="subtitulo_somos">"Nossa Missão"</p>
        <center><div class="linhasub_somos"></div></center>

        <div class="conteudo_somos">
            <div class="poster_somos">
                <img src="IMG/pordosol.jpg" class="poster_img">
            </div>
            <div class="texto_somos">
                <p class="info_somos2">As bicicletas e patinetes da AutoSol são equipadas com baterias especiais, essas que são carregadas em postos espalhados em todas as cidades. Estes postos são equipados com painéis solares de alta eficiência, que captam a energia do Sol e a convertem em eletricidade, essa que é utilizada pra reabastecer as baterias dos nossos itens. 
                    <br>Essa tecnologia é utilizada para diminuir o número de CO2 na atmosfera, trazendo uma alternativa mais saudável tanto para o cliente, quanto para a natureza, com a finalidade de ter postos em todo o Brasil até 2025.</p>
            </div>
        </div>

        <div class="linha_somos"></div>
        <p class="subtitulo_somos">"Onde Estamos"</p>
        <center><div class="linhasub_somos"></div></center>

        <center>
        <div class="localizacao_somos">
            <iframe src="https://www.google.com/maps/embed?pb=!1m18!1m12!1m3!1d3657.201955248638!2d-46.70409592555509!3d
            -23.56118916158418!2m3!1f0!2f0!3f0!3m2!1i1024!2i768!4f13.1!3m3!1m2!1s0x94ce57b035e4a83f%3A0x636c6646169e2d07!
            2sSecretaria%20de%20Meio%20Ambiente%2C%20Infraestrutura%20e%20Log%C3%ADstica%20do%20Estado%20de%20S%C3%A3o%20
            Paulo%20(SEMIL)!5e0!3m2!1spt-PT!2sbr!4v1685817145244!5m2!1spt-PT!2sbr"
            width="100%" height="100%" style="border-radius:10%;" allowfullscreen="" loading="lazy" 
            referrerpolicy="no-referrer-when-downgrade"></iframe>
        </div>
        </center>

    </main>
    <?php
        require_once("includes/footer.php");
    ?>
</body>
</html>
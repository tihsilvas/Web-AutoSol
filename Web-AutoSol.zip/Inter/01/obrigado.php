<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <title>Obrigado</title>
  <link rel="stylesheet" href="CSS/obrigado.css">
  <link rel="stylesheet" href="todos.css">
</head>
<body>

  <div class="caixa-dialogo">
    <h2>Obrigado pela Assinatura!</h2>
    <ul>
      <li>Parabéns pela sua assinatura!</li>
      <li>Sua oportunidade espera por Você</li>
      <li>Apenas escaneie o "QR CODE" com seu aplicativo, para ter acesso às Bicicletas!</li>
    </ul>
    <a href="home.php" class="botao">Voltar</a>
  </div>
</body>
</html>

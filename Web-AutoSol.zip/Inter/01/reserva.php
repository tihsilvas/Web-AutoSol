<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/reserva.css">
    <title>Document</title>
</head>
<body>
    <?php
        require_once("includes/header.php");
    ?>
    <!DOCTYPE html>
        <html lang="pt-BR">
            <head>
            <meta charset="UTF-8">
            <meta name="viewport" content="width=device-width, initial-scale=1.0">
            <title>Planos</title>
            <link rel="stylesheet" href="styles.css">
            </head>
            <body>

            <div id="fundo">
                <div class="plano">
                <h2>Plano Semanal</h2>
                <p class="preco">R$ 10,00</p>
                <p class="por-viagem">Por Viagem</p>
                <ul>
                    <li>7 dias de acesso</li>
                    <li>Recursos exclusivos</li>
                    <li>Bicicleta elétrica grátis por uma semana</li>
                </ul>
                <a href="pagamento.php" class="botao botao1">Assinar Semanal</a>
                </div>

                <div class="plano">
                <h2>Plano Mensal</h2>
                <p class="preco">R$ 30,00</p>
                <p class="por-viagem">Por Viagem</p>
                <ul>
                    <li>30 dias de acesso</li>
                    <li>Recursos premium</li>
                    <li>Mês grátis de utilização da bicicleta elétrica</li>
                </ul>
                <a href="pagamento.php" class="botao">Assinar Mensal</a>
                </div>

                <div class="plano">
                <h2>Plano Anual</h2>
                <p class="preco">R$ 200,00</p>
                <p class="por-viagem">Por Viagem</p>
                <ul>
                    <li>365 dias de acesso</li>
                    <li>Recursos exclusivos</li>
                    <li>Desconto especial</li>
                    <li>Um ano de bicicleta elétrica grátis</li>
                </ul>
                <a href="pagamento.php" class="botao">Assinar Anual</a>
                </div>
            </div>
            <div class="aluguel-div">
                <p class="aluguel-texto">Alugue, Pressionando o Botão a Seguir</p>
                <a href="codigo.php" class="botao-aluguel">Alugar Agora</a>
            </div>
        </body>
    </html>
    <?php
        require_once("includes/footer.php");
    ?>
</body>
</html>
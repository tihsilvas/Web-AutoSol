<!DOCTYPE html>
<html lang="pt-BR">
<head>
  <meta charset="UTF-8">
  <meta name="viewport" content="width=device-width, initial-scale=1.0">
  <link rel="stylesheet" type="text/css" href="CSS/pagamento.css">
  <title>Pagamento com QR Code</title>
</head>
<body class="corpo">
    <div class="cabecalho">
        <h1>Pagamento com QR Code</h1>
    </div>
    <div class="conteudo-container">
        <img class="qrCodeImagem" src="" alt="QR Code">
        <button class="botaoVoltar" onclick="window.location.href='reserva.php'">Cancelar e Voltar</button>
    <script>
        document.addEventListener("DOMContentLoaded", function () {
        const qrCodeImagem = document.querySelector(".qrCodeImagem");
        const codigoBoleto = "1234567890"; // Substitua pelo seu código de boleto
        const qrCodeUrl = `https://api.qrserver.com/v1/create-qr-code/?size=300x300&data=${codigoBoleto}`;
        qrCodeImagem.src = qrCodeUrl;

        setTimeout(function () {
        window.location.href = 'obrigado.php';
        }, 10000);
        });
    </script>
    </div>
</body>
</html>

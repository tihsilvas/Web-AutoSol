<?php
     session_start();
     if(isset($_SESSION['erro_login'])) {
         $erro = $_SESSION['erro_login'];
         unset($_SESSION['erro_login']);
     }
?>

<!DOCTYPE html>
<html lang="pt-br">
<head>
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0" >
    <link rel="stylesheet" type="text/css" href="CSS/formulario.css">
    <title>Formulário de Login</title>
</head>
<body>

    <form method="post" id="form" action="validar.php">
        <center>
        <p class="tituloform">Login de Usuário:</p>
        <center><div class="linhasub_somos"></div></center>
        </center>
        <br>
        <br>
        <label for="email">Email:</label>
        <input type="email" class="campored aviso" name="txt_email" required>
      
        <label for="senha">Senha:</label>
        <input type="password" class="campored aviso" name="txt_senha" required>
        
        <div class="cadastrar">
            <p>Caso você não possua uma conta,<br><a href="cadastro.php">Cadastrar-se</a></p>
        </div>
        <input id="enviar" type="submit" name="login_submit" value="Login">

        <p class="erro">
        <?php if(isset($erro)) { echo $erro; } ?>
    </p>
    </form>
     <script src="JS/formulario.js"></script>
</body>

</html>
<?php
    session_start();

    if(isset($_POST['login_submit'])) {
        require_once "includes/conexao.php";

        $email = $_POST['txt_email'];
        $senha = $_POST['txt_senha'];

        $query = "SELECT * FROM registro WHERE email_cliente='$email' AND senha_cliente='$senha'";
        $result = mysqli_query($conn, $query);

        // if(mysqli_num_rows($result) == 1) {
        //     $_SESSION['email'] = $email;
        //     header('Location: home.php');
        //     $_SESSION['logado'] = true;
        //     exit();

        if(mysqli_num_rows($result) == 1) {
            $usuario = mysqli_fetch_assoc($result);
            $_SESSION['email'] = $email;
            $_SESSION['nome'] = $usuario['txt_nome'];
            $_SESSION['logado'] = true;
            header('Location: home.php');
            exit();
            
        } else {
            $_SESSION['erro_login'] = "Email ou Senha invalido. Tente novamente.";
            header('Location: index.php');
            exit();
        }
    }

?>

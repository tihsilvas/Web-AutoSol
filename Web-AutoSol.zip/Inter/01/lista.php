<?php
	require_once "includes/conexao.php";

    $query = mysqli_query($conn,"SELECT * FROM registro");

    while($rs = mysqli_fetch_array($query)){
        echo $rs['nome_cliente']; ?> <br> <?php
    }
?>
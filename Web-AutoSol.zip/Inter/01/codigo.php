<!DOCTYPE html>
<html>
<head>
  <style>
    body {
      display: flex;
      font-family: 'Times New Roman', Times, serif;
      justify-content: center;
      align-items: center;
      height: 100vh;
      margin: 0;
    }
    #container {
      text-align: center;
      padding: 20px;
      border: 2px solid #3a3212;
      border-radius: 10px;
      background-color: #ffffff;
      color: #3a3212;
      border-radius: 10px;
      text-align: center;
    }
    #mensagem{
        margin: 1vh 1vh 1vh 1vh;
    }
  </style>
</head>
<body>

    <div id="container">
        <h2>Digite o Código a Seguir, Valido por "6 horas"</h2>
        <p id="code"></p>

        <div id="mensagem">Digite o código para obter a bicicleta em um de "Nossos Pontos"</div>
</div>

  <script>
    function generateCode() {
      var code = Math.floor(100000 + Math.random() * 900000);
      document.getElementById("code").innerText = code;
      showHideMessage();
    }
    window.onload = generateCode;
  </script>
  <script src="JS/esperaCódigo.js"></script>

</body>
</html>

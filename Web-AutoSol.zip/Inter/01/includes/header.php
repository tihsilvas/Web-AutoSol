<?php
if (session_status() === PHP_SESSION_NONE) {
    session_start();
}

if (isset($_GET['logout']) && $_GET['logout'] == 1) {
    unset($_SESSION['logado']);
    header('Location: index.php');
    exit();
}

$servidor = "localhost";
$usuario = "root";
$senha = "";
$banco = "inter";
$porta = 3306;

$conn = mysqli_connect($servidor, $usuario, $senha, $banco, $porta);

if (empty($nome)) {
    $email = $_SESSION['email'];

    $query = "SELECT nome_cliente FROM registro WHERE email_cliente = '$email'";
    $result = $conn->query($query);

    if ($result->num_rows > 0) {
        $row = $result->fetch_assoc();
        $nome = $row['nome_cliente'];
    }
}

$conn->close();
?>

<!DOCTYPE html>
<html lang="pt">

<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/header_footer.css">
    <link rel="stylesheet" type="text/css" href="CSS/todos.css">
</head>

<body>
    <header>
        <div class="logo">
            <img src="IMG/logo.png" alt="Logo" style="width: 80%; height: auto;">
        </div>
        <nav class="nav">
            <ul>
                <li><a class="item" href="home.php">Home</a></li>
                <li><a class="item" href="reserva.php">Aluguel</a></li>
                <li><a class="item" href="dicas.php">Dicas</a></li>
                <li><a class="item1 item" href="quemsomos.php">Sobre</a></li>
            </ul>
        </nav>

        <?php
        if (isset($_SESSION['nome'])) {
            $nome = $_SESSION['nome'];
            echo '<style>.perfil-icone label { display: inline; }</style>';
        }
        ?>
<style>
    .perfil-icone {
        color: white;
        text-decoration: none;
        display: flex;
        align-items: center;
    }

    .perfil-icone label {
        margin-left: -100px; 
    }

    .perfil-icone img {
        width: 30px; 
        height: auto;
    }
</style>
        <a class="perfil-icone" href="logout.php">
            <label><?php echo isset($nome) ? $nome : 'Logout'; ?></label>
            <img src="IMG/perfil-de-usuario.png">
        </a>

    </header>
</body>

</html>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/header_footer.css">
    <link rel="stylesheet" type="text/css" href="CSS/todos.css">
    <title>Index</title>
</head>
<body>
<footer>
    <div class="container-footer">
      <div class="dados-footer">Rua Maquenzie, 133, 
        <br>São Paulo, São Paulo, Brasil
        <br>(11) 98634-5678
        <br>autosol@auto.com</div>
    </div>
    <div class="container-footer">
      <div class="container-footer2">
        <div class="icon-container">
          <img class="icon" src="IMG/facebook.png" ><a href="https://www.facebook.com">
          <div class="text-icon">Facebook</div>
        </div>
        <div class="icon-container">
          <img class="icon2" src="IMG/linkedin.png" ><a href="https://www.linkedin.com">
          <div class="text-icon">Linkedin</div>
        </div>
      </div>

      <div class="container-footer2">
        <div class="icon-container">
          <img class="icon" src="IMG/twitter.png" ><a href="https://twitter.com">
          <div class="text-icon icon3">X (Antigo Twitter)</div>
        </div>
        <div class="icon-container icon4">
          <img class="icon2" src="IMG/instagram.png" ><a href="https://www.instagram.com">
          <div class="text-icon">Instagram</div>
        </div>
      </div>
    </div>
  </footer>
</body>
</html>
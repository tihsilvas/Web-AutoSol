<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Document</title>
</head>
<body>
    <title>Quais suas Dúvidas?</title>
    <?php
        require_once("includes/header.php");
    ?>

    <div class="reser">
        <div class="titulo"><b>Bem-vindo á AutoSol!</b></div>
        <div class="explicação">
        1. Para utilizar nossas Bikes, você precisara de um cadastro em nossos serviços.
        <br>
        2. Depois, faça a assinatura no nosso site/aplicativo, assim tendo acesso as nossas bikes.
        <br>
        3. Após a assinatura, você podera ler um qr code em um de nossos pontos.
        <br>
        4. Lembre-se que o cliente sempre deverá retornar as Bicicletas para um de nossos pontos, caso aconteça o abandono, as autoriedades seram chamadas.
    </div>
    <div class="bike"><img class="bike" src="IMG/BikeComousar.jpg"></div>
    </div>
    <div class="reser">
    <div class="titulo"><b>Tutorial de Pagamento</b></div>
        <div class="explicação">
        Após colocar os dados do cartão em uma de nossas maquinas, será cobrado mensalmente o valor da assinatura.
        <br>
        Será possível que o cliente cancele a assinatura a qualquer momento, pelo aplicativo.
        <br>
        <br>
        1- Cartões De Débito aceitos: Elo, Bradesco, Itaú, Banco do Brasil, Revolut, Nomad.
        <br>
        2- Cartões de Crédito aceitos: Bradesco, Mastercard, PagBank, Neon Visa, Nubank.
    </div>
    <div class="card"><img class="card" src="IMG/CardComousar.png"></div>
    </div>
    
    
    <?php
        require_once("includes/footer.php");
    ?>
    
    <link rel="stylesheet" type="text/css" href="CSS/dicas.CSS ">
</body>
</html>
<?php
session_start();

if (!isset($_SESSION['logado']) || $_SESSION['logado'] !== true) {
    header('Location: index.php');
    exit();
}
?>

<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="CSS/home.css">
  
    <title>Index</title>
</head>
<body>
    <?php
        require_once("includes/header.php");
    ?>

    <main>
        <div class="slider-container">
            <div class="slide">
            <img src="IMG/slidder.jpg" alt="Slide Image" style="width: 100%; height: 90vh ">
            </div>
        </div>
        <div class="container">
            <div class="container-circ"><img src="IMG/bike.jpg" width="100%" height="100%"></div>
            <div class="container-text">Bicicletas: Essas bicicletas são equipadas com baterias especiais, podendo andar de 15 á 25km por hora.
            <br>Existem diversos modelos disponiveis, então a vida da bateria poderá variar de 10 á 20 horas.</div>
        </div>
        <div class="container">
            <div class="container-text c2">Patinetes: Esses patinetes são equipados com baterias especiais, levemente menos potentes do que as das bicicletas, podendo andar de 10 á 15km por hora.
            <br>Existem diversos modelos disponiveis, então a vida da bateria poderá variar de 5 á 15 horas.</div>
            <div class="container-circ"><img src="IMG/patinete.jpg"></div>
        </div>
    </main>

        <?php
            require_once("includes/footer.php");
        ?>
</body>
</html>
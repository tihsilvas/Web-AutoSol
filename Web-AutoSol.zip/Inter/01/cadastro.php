<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE-Edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <link rel="stylesheet" type="text/css" href="css/formulario.css">
</head>
	<body>
        <form name="frmCad" id="form1" method="post" action="processar.php" enctype="multipart/form-data">
            <center>
                <p class="titulocad">Formulario de Cadastro</p>
            <div class="linha_cad"></div>
            </center>
            <div class="separacad">
                <p class="sub_titulocad">Dados do Cadastro:</p>
                <div class="conteudocad">
                    <label class="textcampocad">Digite seu E-mail:</label>
                    <input type="email" name="txt_email" class="campocad aviso" required oninput="emailAviso()"></input>
                </div>
                <div class="avisotext">Parâmetro: nome@servidor.com</div>
                <div class="conteudocad">
                    <label class="textcampocad">Digite sua Senha:</label>
                    <input type="password" name="txt_senha" class="campocad aviso" required oninput="senhaAviso()"></input>
                </div>
                <div class="avisotext avisotext2">Mínimo 6 Caracteres</div>
            </div> 
            <!-- Separa Coluna -->
            <div class="separacad">
                <div class="conteudocad conteudocad2">
                    <label class="textcampocad">Repita a Senha:</label>
                    <input type="password" name="txt_Rsenha" class="campocad aviso" required oninput="compareSenha()"></input>
                    <br>
                </div>
                <div class="avisotext avisotext2">Repita a Senha</div>
            </div>
            <div class="linha_cad"></div>
            <!-- Separa Coluna -->
            <div class="separacad">
                <p class="sub_titulocad">Dados Pessoais do Cliente:</p>
                <div class="conteudocad">
                    <label class="textcampocad">Nome Completo:</label>
                    <input type="text" name="txt_nome" class="campocad aviso" required oninput="nomeAviso()"></input>
                </div>
                <div class="avisotext avisotext2">3 Caracteres no Mínimo</div>
                <div class="conteudocad">
                    <label class="textcampocad">Data de Nascimento:</label>
                    <input type="date" name="txt_data" class="campocaddata aviso" required></input>
                </div>
                <div class="avisotext">.</div>
                <div class="conteudocad">
                    <label class="textcampocad">RG:</label>
                    <input type="text" name="txt_rg" class="campocad aviso" required oninput="rgAviso()"></input>
                </div>
                <div class="avisotext avisotext3">RG Invalido</div>
                <div class="conteudocad">
                    <label class="textcampocad">CPF:</label>
                    <input type="text" name="txt_cpf" class="campocad aviso" required oninput="cpfAviso()"></input>
                </div>
                <div class="avisotext avisotext3">CPF Invalido</div>
                <div class="conteudocad">
                    <label class="textcampocad">Telefone:</label>
                    <input type="number" name="txt_fone" class="campocad aviso" oninput="foneAviso()"></input>
                </div>
                <div class="avisotext avisotext3">Parâmetro DD+Telefone</div>
            </div> 
            <!-- Separa Coluna -->
            <div class="separacad">
                <p class="sub_titulocad">Endereço do Cliente:</p>
                <div class="conteudocad">
                    <label class="textcampocad">CEP</label>
                    <input type="number" name="txt_cep" class="campocad aviso" oninput="cepAviso()"></input>
                </div>
                <div class="avisotext marginAviso avisotext3">CEP Invalido</div>
                <div class="conteudocad">
                    <label class="textcampocad">Estado:</label>
                    <select id="estado" name="txt_estado" class="campocad aviso">
                        <option value="AC">Acre</option>
                        <option value="AL">Alagoas</option>
                        <option value="AP">Amapá</option>
                        <option value="AM">Amazonas</option>
                        <option value="BA">Bahia</option>
                        <option value="CE">Ceará</option>
                        <option value="DF">Distrito Federal</option>
                        <option value="ES">Espírito Santo</option>
                        <option value="GO">Goiás</option>
                        <option value="MA">Maranhão</option>
                        <option value="MT">Mato Grosso</option>
                        <option value="MS">Mato Grosso do Sul</option>
                        <option value="MG">Minas Gerais</option>
                        <option value="PA">Pará</option>
                        <option value="PB">Paraíba</option>
                        <option value="PR">Paraná</option>
                        <option value="PE">Pernambuco</option>
                        <option value="PI">Piauí</option>
                        <option value="RJ">Rio de Janeiro</option>
                        <option value="RN">Rio Grande do Norte</option>
                        <option value="RS">Rio Grande do Sul</option>
                        <option value="RO">Rondônia</option>
                        <option value="RR">Roraima</option>
                        <option value="SC">Santa Catarina</option>
                        <option value="SP">São Paulo</option>
                        <option value="SE">Sergipe</option>
                        <option value="TO">Tocantins</option>
                    </select>
                </div>
                <div class="avisotext marginAviso"></div>
                <div class="conteudocad">
                    <label class="textcampocad">Cidade:</label>
                    <input type="text" name="txt_cidade" class="campocad aviso"></input>
                </div>
                <div class="avisotext marginAviso"></div>
                <div class="conteudocad">
                    <label class="textcampocad">Rua:</label>
                    <input type="text" name="txt_rua" class="campocad aviso"></input>
                </div>
                <div class="avisotext marginAviso"></div>
                <div class="conteudocad">
                    <label class="textcampocad">Bairro:</label>
                    <input type="text" name="txt_bairro" class="campocad aviso"></input>
                </div>
                <div class="avisotext marginAviso"></div>
                <div class="conteudocad">
                    <label class="textcampocad">Complemento:</label>
                    <input type="text" name="txt_complemento" class="campocad aviso"></input>
                </div>
                <button type="reset" class="btn1">Limpar</button>
                <button type="submit">Enviar</button>

            </div> 
			
			</form>
		<script src="JS/formulario.js"></script>
	</body>
</html>
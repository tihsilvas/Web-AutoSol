const form = document.getElementById('form');
const campos = document.querySelectorAll('.aviso');
const spans = document.querySelectorAll('.avisotext');
const spans2 = document.querySelectorAll('.loginAviso');
var botao = document.getElementyById('enviar');
const emailRegex = /^[a-z0-9.]+@[a-z0-9]+\.[a-z]+\.?$/i;

function emailAviso(){
	if(!emailRegex.test(campos[0].value)){
		pegaErro(0);
	}
	else
	{
		removeErro(0);
	}
}
function senhaAviso(){
	if(campos[1].value.length < 6)
	{
		pegaErro(1);
	}
	else
	{
		removeErro(1);
		compareSenha();
	}
}
function compareSenha(){
	if(campos[1].value == campos[2].value && campos[2].value.length >= 6){
		removeErro(2);
	}
	else
	{
		pegaErro(2);
	}
}
function nomeAviso(){
	if(campos[3].value.length > 3){
		removeErro(3);
	}
	else
	{
		pegaErro(3);
	}
}
function rgAviso(){
	if(campos[5].value.length <= 10 && campos[5].value.length >= 7){
		removeErro(5);
	}
	else
	{
		pegaErro(5);
	}
}
function cpfAviso(){
	if(campos[6].value.length <= 12 && campos[6].value.length >= 10){
		removeErro(6);
	}
	else
	{
		pegaErro(6);
	}
}
function foneAviso(){
	if(campos[7].value.length < 12 && campos[7].value.length > 10){
		removeErro(7);
	}
	else
	{
		pegaErro(7);
	}
}
function cepAviso(){
	if(campos[8].value.length < 9 && campos[8].value.length > 7){
		removeErro(8);
	}
	else
	{
		pegaErro(8);
	}
}

function pegaErro(index){
	campos[index].style.border ='1px solid #e63636';
	spans[index].style.color = 'red';
}

function removeErro(index){
	campos[index].style.border = '';
	spans[index].style.color = '';
}
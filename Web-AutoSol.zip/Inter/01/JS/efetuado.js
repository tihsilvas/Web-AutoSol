setTimeout(function () {
    window.location.href = 'index.php?status=success';
}, 3000);


setTimeout(function () {
    window.location.href = 'home.php?';
}, 10000);
<?php
	require_once "includes/conexao.php";

    $email = $_POST['txt_email'];
    $senha = $_POST['txt_senha'];
    $nome = $_POST['txt_nome'];
    $cpf = $_POST['txt_cpf'];
    $dt_nasc = $_POST['txt_data'];
	$rg = $_POST['txt_rg'];
    $fone = $_POST['txt_fone'];
    $cep = $_POST['txt_cep'];
    $estado = $_POST['txt_estado'];
    $cidade = $_POST['txt_cidade'];
    $rua = $_POST['txt_rua'];
    $bairro = $_POST['txt_bairro'];
    $complemento = $_POST['txt_complemento'];

	$query = "INSERT into registro (email_cliente, 
    senha_cliente, nome_cliente, cpf_cliente, 
    dt_nasc_cliente, rg_cliente, telefone_cliente, cep_cliente,
    estado_cliente, cidade_cliente, rua_cliente, bairro_cliente, comp_cliente)
     VALUES ('$email', '$senha', '$nome', '$cpf', '$dt_nasc', 
     '$rg', $fone, $cep, '$estado', '$cidade', '$rua', '$bairro',
     '$complemento')";
	$sql = mysqli_query($conn,$query);

	$n = mysqli_affected_rows($conn);

    
?>
<!DOCTYPE html>
<html lang="pt-br">

<head>
    <meta charset="UTF-8">
    <meta http-equiv="X-UA-Compatible" content="IE=edge">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">
    <title>Cadastro Efetuado com Sucesso</title>
    <style>
       body {
            display: flex;
            justify-content: center;
            align-items: center;
            height: 100vh;
            margin: 0;
            font-family: 'Times New Roman', Times, serif;

            background-image: url("../IMG/fundo1.jpg");
            background-size: cover;
            background-repeat: no-repeat;
            background-attachment: fixed; 
        }
        .mensagem {
            text-align: center;
            padding: 20px;
            border: 2px solid #3a3212;
            border-radius: 10px;
        }
        h1 {
            color: #3a3212;
        }
    </style>
</head>

<body>
    <div class="mensagem">
        <h1>Cadastro Efetuado com Sucesso!</h1>
    </div>

    <script src="JS/efetuado.js"></script>
</body>

</html>

